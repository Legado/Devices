
C-NaviGator Rescue Image README
-------------------------------

This is the README file from the zip file containing the rescue image
for a touchscreen C-NaviGator.  When installed on a USB drive, this
can be used to completely reinstall a touchscreen C-NaviGator.


Needed Items
------------

- The rescue zip file
- A USB drive with enough space (a little over 100 MB) formatted as FAT
  (not NTFS)
- A computer running Windows (to unzip the zip file onto the USB drive)
- A PS/2 or USB keyboard to connect to the C-NaviGator

  Optionally, if you do not have a suitable USB disk available, but
  you do have a USB CD-ROM drive, you can use this.  See Section IB
  below.  For this option, you also need:

  - a writable CD
  - a USB CD-ROM drive


I. Installing the rescue image on the USB drive
-----------------------------------------------

1. Attach the USB drive to the Windows computer
   (From here on, we will assume the drive was detected as X: - replace X:
    with the actual letter of the drive on your computer).

2. Using your favorite Windows zip extraction software, extract the rescue
   zip file into the top-level folder of the USB drive.  When this is done,
   there should be a folder called "syslinux" (e.g. X:\syslinux).

3. Open the USB drive in My Computer and navigate into the syslinux folder.
   You should see several files, one of which is named "install.bat".

4. Double-click on install.bat to run it.  This makes the USB drive
   bootable and make it run the installation program on boot.  A
   command prompt window will pop up to show you the results.  Press
   ENTER to continue.

5. Make sure the computer is finished writing to the USB drive (use the Safely
   Remove Hardware tray icon if necessary), then remove the drive from the
   computer.


   OR.... (skip to Section II if using a USB drive)


IB. Installing the rescue image on a CD for use in a USB CD-ROM drive
---------------------------------------------------------------------

1. Using your favorite Windows zip extraction software, extract the rescue
   zip file onto the computer's hard drive.  When this is done,
   there should be a folder called "syslinux" wherever you unzipped it.

2. Inside the syslinux folder there will be a file called
   cnrescue.iso.  Using your favorite Windows CD burning software, burn
   this ISO file to a CD.

3. Put the CD in a USB CD-ROM drive.  In the instructions below,
   wherever it refers to the USB drive, use the CD-ROM drive.  Take
   note that the BIOS settings for enabling boot from a CD-ROM drive
   are slightly different as indicated below.


II. Using the USB drive to install a touchscreen C-NaviGator
------------------------------------------------------------

1.  Turn off the C-NaviGator.

2.  Connect the keyboard to the C-NaviGator.

3.  Disconnect all other USB devices from the C-Navigator.

4.  Connect the USB drive with the rescue image on it to the C-NaviGator.

5.  Turn on the C-NaviGator.

6.  When the blue C-Nav logo screen comes up, hit Delete on the keyboard
    a few times.  You should enter the C-NaviGator's BIOS configuration
    screen.  If the BIOS config screen does not come up, turn off the
    C-NaviGator and try again.  (Sometimes it seems to take a few tries).

7.  At the main BIOS config screen, select "Advanced BIOS Features".
    When you enter that screen, set "First Boot Device" to "USB-ZIP".
    (If using a CD-ROM drive, select "USB-CDROM" instead of "USB-ZIP".)
    All the other boot devices should be set to "Disabled".  Hit F10 to
    save and exit the BIOS screen.

8.  The C-NaviGator will now reboot and should boot off of the USB drive.
    Lots of messages will print on screen from the installation program.
    It will take a few seconds for the installation program to locate the
    install image on the USB drive.  When it does, it will prompt you to
    hit ENTER to begin the installation.

9.  After you hit ENTER, the installation will proceed.  Don't do
    something silly like unplug the USB drive while the installation is
    running.  When the installation is done, it will display a message
    prompting you to hit ENTER or touch the screen anywhere to continue.

10. After you hit ENTER again, the C-NaviGator displays a message
    prompting you to turn off the C-NaviGator, disconnect the USB drive,
    then turn the C-NaviGator on again.  Do this - but get ready to
    press Delete on the keyboard when you turn the C-NaviGator on again.
    You have to return the BIOS to its original boot settings.

11. Make sure you do this before returning the C-NaviGator to a customer.

    Hit Delete as before to enter the C-NaviGator's BIOS config
    screen.  As before, enter the "Advanced BIOS Features" screen.  Set
    the "First Boot Device" back to "Hard Disk".  Leave the other
    boot devices as "Disabled".  Hit F10 to save the BIOS settings and
    exit.

12. Verify that the C-NaviGator boots and that the software starts up.
